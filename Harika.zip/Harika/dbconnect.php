<?php
$server='localhost';
$user='root';
$pass='';
$db='blog';
$conn=new mysqli($server,$user,$pass,$db);
?>

