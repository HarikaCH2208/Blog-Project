<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Delete Blogs</title></head>
<body>
        <!--/. NAV TOP  -->
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
			   <div class="col-md-12">
			     <h1 class="page-header">Delete Blogs</h1>
               
               </div>
</div>             
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table width="848" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
    <td width="102"><div align="center">slno</div></td>
    <td width="276"> <div align="center">Blog Title </div></td>
    <td width="454"><div align="center">Blog Content </div></td>
	<td width="454"><div align="center">Delete </div></td>
  </tr>
  </thead>
  <tbody>
    <?php
 
  include("dbconnect.php");
  $sl=1;
  $sql="select* from post ";
  //where email='$uname' 
  $res=mysqli_query($conn,$sql);
  while($row=mysqli_fetch_array($res))
  {
   ?>
  <tr>
    <th height="41"><?php echo $sl++; ?></th>
    <th><?php echo $row['title']; ?></th>
    <th><?php echo $row['content']; ?></th>
    
   <!-- <th><a href="medical_reports_edit.php?b_p=<?php echo $row['Report_no'];?>"><img src="../img/edit.png" width="34" height="36"></a></th>!-->
    <th><a href="delete.php?po_id=<?php echo $row['p_id'];?>"onClick="return confirm('Do you want to delete?')"><img src="img/delete.jpeg" width="34" height="36"></a></th>
  </tr>
  <?php } ?>
</tbody>
                              </table>
                            </div>
                            
                        </div>
                    </div>
                      
                <div class="col-md-6">
                     <!--    Context Classes  -->
                    <div class="panel panel-default">
                    </div>
                    <!--  end  Context Classes  -->
                </div>
            </div>
                <!-- /. ROW  -->
        </div>
</body>
</html>


</body>
</html>