<?php
include('dbconnect.php');
$po_id=$_POST['po_id'];
$title=$_POST['title'];
$content=$_POST['content'];

$sql="update post set  title='$title',content='$content' where p_id='$po_id'";
mysqli_query($conn,$sql);
?>
<script>
alert("values updated");
document.location="edit_view.php"
</script>