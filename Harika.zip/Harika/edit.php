<?php include 'dbconnect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Blog Post</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            width: 100%;
            height: 600px;
            max-width: 1000px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        input, textarea {
            width: 100%;
            padding: 20px;
            margin-bottom: 20px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            padding: 16px;
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        a {
            color: #007bff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<?php 
include("dbconnect.php");
$post_id=$_REQUEST['po_id'];
$sql="select * from post where p_id='$post_id'";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($res);
?>
<!--<form name="form1" method="post" action="Past_records_update.php">!-->
    
    <form action="update.php" method="post">
	<input type="hidden" name="po_id" value="<?php  echo $row['p_id'];?>">
        <h2>Edit a Blog Post</h2>
        <label for="title">Title:</label>
        <input name="title" type="text" value="<?php echo $row['title']; ?>" required>
        <br>

        <label for="content">Content:</label>
        <input name="content" rows="18" value="<?php echo $row['content']; ?>" required><br>

        <input type="submit" value="Publish">
    </form>

  <!--  <script>
        function showSuccessAlert() {
            alert("Blog successfully created!");
            return true; // Continue with form submission
        }
    </script> !-->
</body>
</html>