<?php
include('dbconnect.php');
$tit=$_POST['title'];
$cont=$_POST['content'];

$sql="insert into post values (null,'$tit','$cont')";
mysqli_query($conn,$sql);


echo "Inserted";

?>
<script>
alert("Values Inserted");
document.location="home.php"
</script>