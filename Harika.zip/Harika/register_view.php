<table width="873" height="119" border="1" align="center">
  <tr>
    <td width="126"><div align="center">Sl.NO</div></td>
    <td width="181"><div align="center">Name</div></td>
    <td width="191"><div align="center">Password</div></td>
    <td width="142"><div align="center">Email</div></td>
    <td width="99"><div align="center">Edit</div></td>
	<td width="94"><div align="center">Delete</div></td>
  </tr>
  
  <tr>
      <?php
 
  include("dbconnect.php");
  $sl=1;
  $sql="select* from users ";
  //where email='$uname' 
  $res=mysqli_query($conn,$sql);
  while($row=mysqli_fetch_array($res))
  {
   ?>
  <tr>
    <th height="41"><?php echo $sl++; ?></th>
    <th><?php echo $row['username']; ?></th>
    <th><?php echo $row['password']; ?></th>
	<th><?php echo $row['email']; ?></th>
    
   <th><a href="register_edit.php?us_id=<?php echo $row['user_id'];?>"><img src="img/edit.png" width="34" height="36"></a></th>
   <th><a href="register_delete.php?us_id=<?php echo $row['user_id'];?>"onClick="return confirm('Do you want to delete?')"><img src="img/delete.jpeg" width="34" height="36"></a></th>
  </tr>
  <?php } ?>
    
    
</table>
