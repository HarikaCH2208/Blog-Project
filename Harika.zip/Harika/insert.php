<?php
include('dbconnect.php');
$name=$_POST['username'];
$pass=$_POST['password'];
$email=$_POST['email'];

$sql="insert into users values (null,'$name','$pass','$email')";
mysqli_query($conn,$sql);
$sql1="insert into login values ('$name','$pass')";
mysqli_query($conn,$sql1);

echo "Inserted";

?>
<script>
alert("Successfully Registered");
document.location="login.php"
</script>