<?php
include('dbconnect.php');
$us_id=$_POST['us_id'];
$username=$_POST['username'];
$password=$_POST['password'];
$email=$_POST['email'];

$sql="update users set  username='$username',password='$password',email='$email' where user_id='$us_id'";
mysqli_query($conn,$sql);
?>
<script>
alert("values updated");
document.location="register_view.php"
</script>