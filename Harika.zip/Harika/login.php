<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <form action="home.php" method="POST">
		<p>Don't have an account? <a href="register.php">Register here</a></p>
            <h2>Login</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
        </form>
    </div>
	<script>
    document.addEventListener("DOMContentLoaded", function () {
      const label = document.querySelector(".text-checkbox");
      const checkbox = document.getElementById("rememberCheckbox");

      label.addEventListener("click", function () {
        checkbox.checked = !checkbox.checked;
      });

      // Adding an additional event listener to handle clicks on the checkbox itself
      checkbox.addEventListener("click", function (event) {
        event.stopPropagation(); // Prevent label click event from being triggered
      });
	const loginForm = document.getElementById("loginForm");
      loginForm.addEventListener("submit", function (event) {
        event.preventDefault();
        const userType = document.getElementById("userType").value;
        switch (userType) {
          case "admin":
            window.location.href = "home.php"; // Replace with actual URLs
            break;
          default:
            alert("Please select a valid user type.");
        }
      });
    });
  </script>
</body>
</html>
