<?php
include('dbconnect.php');
$u_id=$_REQUEST['us_id'];
$sql="delete from users where user_id='$us_id'";
mysqli_query($conn,$sql);
?>
<script>
alert("value deleted successfully");
document.location="register_view.php";
</script>