<?php session_start();?>
<?php
include('dbconnect.php');

$username=$_POST['username'];
$password=$_POST['password'];
//$type=$_POST['type'];
//include('dbconnect.php');
$sql="select * from login where username='$username' and password='$password'";
$res=mysqli_query($conn,$sql);
if($row=mysqli_fetch_array($res))
{
$_SESSION['uname']=$username;
$type=$row['username'];


if($type=="admin")
{
header('location:admin/home.php');
}


else if($type=="user")
{
$sql="select * from  customer_details where username='$username'";
  $res=mysqli_query($conn,$sql);
  $row=mysqli_fetch_array($res);
  $_SESSION["customer_id"]=$row["customer_id"];
header('location:web/user_home.php');
}

}
else
{
?>
<script>
alert("Invalid Username Or Password");
history.back();
</script>
<?php
}

?>