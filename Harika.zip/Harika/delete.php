
<?php
include('dbconnect.php');
$post_id=$_REQUEST['po_id'];
$sql="delete from post where p_id='$post_id'";
mysqli_query($conn,$sql);
?>
<script>
alert("value deleted successfully");
document.location="delete_view.php";
</script>